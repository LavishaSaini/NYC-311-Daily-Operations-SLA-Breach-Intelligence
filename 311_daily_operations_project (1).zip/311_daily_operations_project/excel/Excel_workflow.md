# Excel workflow

1. Import `data/nyc311_requests_2025_q1.csv` with **Data > From Text/CSV**. Select **Transform Data** and confirm date/time types.
2. In Power Query, remove blank request IDs, trim text columns, and replace blank borough values with `Unknown`.
3. Add a PivotTable named `DailyOps`: Rows = `created_date`, Columns = `borough`, Values = Count of `request_id`, Sum of `is_overdue`, Sum of `priority_score`.
4. Add a second PivotTable named `AgencySLA`: Rows = `agency_name`, Values = Count of `request_id`, Average of `response_hours`, Sum of `is_overdue`, Average of `is_closed`.
5. Add slicers for `borough`, `agency_name`, `complaint_type`, and `risk_band`.
6. Use conditional formatting: red fill for `risk_band = High`, amber for `Medium`, and data bars for request count.
7. Add a small action box: “Today’s focus = borough + complaint type with the highest High Risk Requests.”

Useful Excel formulas if working from an Excel Table named `Requests`: 
`=COUNTIFS(Requests[created_date],A2,Requests[borough],B$1)`
`=AVERAGEIFS(Requests[response_hours],Requests[agency_name],A2)`
`=SUMIFS(Requests[is_overdue],Requests[borough],A2)`
