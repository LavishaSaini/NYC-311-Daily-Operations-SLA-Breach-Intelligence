# NYC 311 Daily Operations & SLA Breach Intelligence

## Project summary
This project converts daily 311 service requests into an operational decision system. The objective is to answer a practical question: **which complaint categories and boroughs need attention today because demand, response time, or SLA risk is increasing?** The project uses a real public dataset from NYC Open Data, SQL for investigation, Excel for an analyst-friendly operating view, and Power BI for an executive dashboard.

The included extract contains **100 service requests** created during Q1 2025. It is a reproducible extract, not a fabricated dataset. The source is updated by NYC Open Data, so results will change if the extraction window is refreshed.

## Business questions
The dashboard is designed to identify the daily workload queue, compare agency response performance, detect borough-level complaint concentration, and show demand patterns by hour and day. A manager should be able to move from a KPI to a specific action: for example, investigate a high-risk complaint type in a borough, review the responsible agency, and check whether the issue is recurring.

## Data and methodology
The source table is NYC’s “311 Service Requests from 2020 to Present.” Each row represents a service request. The analysis derives response hours from the difference between closed and created timestamps. `High` risk is assigned to open requests or requests with response time above 72 hours; `Medium` risk is assigned to response time above 24 hours. These are analyst-defined triage rules for demonstration and should be validated with the operating team before production use.

## Deliverables
| File | Purpose |
|---|---|
| `data/nyc311_requests_sample.csv` | Cleaned source extract with derived fields |
| `data/daily_borough_summary.csv` | Validation summary for Excel/Power BI |
| `sql/01_schema_and_analysis.sql` | Schema, operating queries, QA checks, window-function example |
| `powerbi/DAX_measures.txt` | Measures and report-page specification |
| `excel/Excel_workflow.md` | Power Query, PivotTable, slicer, and conditional-formatting workflow |

## Interview narrative
I built an operations dashboard using NYC 311 service requests. I cleaned timestamps and text fields, engineered response-time, closure, overdue, and risk indicators, and used SQL aggregations and window functions to find agency and borough hotspots. In Power BI, I created an executive pulse, SLA comparison, action queue, and demand heatmap. The differentiator is that the dashboard does not stop at volume reporting: it prioritizes the next operational action using transparent triage logic.

## Resume bullets
* Built an end-to-end **NYC 311 Daily Operations & SLA Breach Intelligence** solution using SQL, Excel Power Query/PivotTables, and Power BI on 100 real service requests.
* Engineered response-time, closure-rate, overdue, and risk-band metrics; used SQL CTEs, `RANK()` window functions, and QA checks to identify agency and borough-level operational hotspots.
* Designed a Power BI dashboard with executive KPIs, agency SLA comparison, daily action queue, and demand heatmap to translate complaint volume into prioritized workload decisions.

## How to explain it in an interview
Start with the business problem rather than the tools. Explain that leadership needed to know where the next day’s workload risk was, not merely how many requests arrived. Then describe the data model, the derived metrics, the SQL validation, and the dashboard decisions. Be explicit that the risk thresholds are a transparent prototype and that a production rollout would calibrate them against official SLA policy.

## Limitations
The extract is a 100-row sample and focuses on service requests that are directed to agencies. It does not prove causality or measure customer satisfaction. Location values can be missing or imprecise. A production version should add a calendar table, official SLA targets by complaint type, refresh monitoring, row-level security where needed, and a documented data-quality owner.

## References
[1]: https://data.cityofnewyork.us/Social-Services/311-Service-Requests-from-2020-to-Present/erm2-nwe9 "NYC Open Data: 311 Service Requests from 2020 to Present"
[2]: https://dev.socrata.com/foundry/data.cityofnewyork.us/erm2-nwe9 "Socrata API documentation for the NYC 311 dataset"
