-- NYC 311 Daily Operations & SLA Breach Intelligence
-- Load data/nyc311_requests_2025_q1.csv into dbo.nyc311_requests.

CREATE TABLE nyc311_requests (
 request_id BIGINT PRIMARY KEY, created_at TIMESTAMP, closed_at TIMESTAMP, created_date DATE,
 week_start DATE, created_hour INT, day_name VARCHAR(12), agency VARCHAR(20), agency_name VARCHAR(150),
 complaint_type VARCHAR(150), descriptor VARCHAR(250), borough VARCHAR(40), status VARCHAR(30), channel VARCHAR(40),
 due_date TIMESTAMP, latitude DECIMAL(10,7), longitude DECIMAL(10,7), response_hours DECIMAL(12,2),
 is_closed INT, is_overdue INT, priority_score INT, risk_band VARCHAR(10)
);

-- 1) Daily operating queue: where should the team focus today?
SELECT created_date, borough, complaint_type, COUNT(*) AS requests,
       SUM(CASE WHEN risk_band = 'High' THEN 1 ELSE 0 END) AS high_risk,
       ROUND(AVG(response_hours),2) AS avg_response_hours
FROM nyc311_requests
GROUP BY created_date, borough, complaint_type
ORDER BY created_date DESC, high_risk DESC;

-- 2) SLA/closure performance by agency.
SELECT agency, agency_name, COUNT(*) AS total_requests,
       SUM(is_closed) AS closed_requests,
       ROUND(100.0*SUM(is_closed)/NULLIF(COUNT(*),0),2) AS closure_rate_pct,
       ROUND(AVG(response_hours),2) AS avg_response_hours,
       SUM(is_overdue) AS overdue_requests
FROM nyc311_requests
GROUP BY agency, agency_name
ORDER BY overdue_requests DESC;

-- 3) Repeat hotspot proxy: borough + complaint type concentration.
WITH ranked AS (
 SELECT borough, complaint_type, COUNT(*) AS requests,
        RANK() OVER (PARTITION BY borough ORDER BY COUNT(*) DESC) AS rank_in_borough
 FROM nyc311_requests
 GROUP BY borough, complaint_type
)
SELECT * FROM ranked WHERE rank_in_borough <= 5 ORDER BY borough, rank_in_borough;

-- 4) Demand pattern by hour and day.
SELECT day_name, created_hour, COUNT(*) AS requests,
       ROUND(AVG(response_hours),2) AS avg_response_hours
FROM nyc311_requests
GROUP BY day_name, created_hour
ORDER BY requests DESC;

-- 5) Analyst QA checks.
SELECT COUNT(*) AS row_count, COUNT(DISTINCT request_id) AS unique_ids,
       SUM(CASE WHEN created_at IS NULL THEN 1 ELSE 0 END) AS missing_created_at,
       SUM(CASE WHEN response_hours < 0 THEN 1 ELSE 0 END) AS negative_response_hours
FROM nyc311_requests;
